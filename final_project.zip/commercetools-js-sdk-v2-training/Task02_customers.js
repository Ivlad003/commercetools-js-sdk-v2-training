const {
  createCustomer,
  getCustomerById,
  getCustomerByKey,
  createCustomerKeyVerfiedEmail,
  assignCustomerToCustomerGroup,
} = require("./handson/customer");
const { log } = require("./logger.js");

const customerSampleData = {
  firstName: "Ihor",
  lastName: "Bilous",
  email: "exmdmetal2@test.com",
  password: "qwe123qwe123",
  key: "exmdmetal2",
  countryCode: "DE",
};

// createCustomer(customerSampleData).then(log).catch(log);

// getCustomerByKey('exmdmetal2').then(log).catch(log);

// getCustomerById("162d0aff-79b8-4f8e-9d21-cb57998345b1").then(log).catch(log);

// createCustomerKeyVerfiedEmail(customerSampleData).then(log).catch(log);

// assignCustomerToCustomerGroup('exmdmetal2','indoor-group').then(log).catch(log);
