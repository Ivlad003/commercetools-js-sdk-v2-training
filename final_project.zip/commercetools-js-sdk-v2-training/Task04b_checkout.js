const checkout = require("./handson/order");
const { log } = require("./logger.js");

const cartDraftData = {
  currency: "EUR",
  customerId: "162d0aff-79b8-4f8e-9d21-cb57998345b1",
  countryCode: "DE",
};
const paymentDraft = {
  key:"exmdmPayment13",
  amountPlanned:{
    currencyCode:'EUR',
    centAmount:4200
  },
  customer:{
    typeId:'customer',
    id:'162d0aff-79b8-4f8e-9d21-cb57998345b1'
  }
}

// checkout.createCart(cartDraftData).then(log).catch(log)

// checkout.addLineItemsToCart(['123','123'],'0da6ec84-4804-4e7d-a33e-76cb4aa367de').then(log).catch(log)

//checkout.getCartById('0da6ec84-4804-4e7d-a33e-76cb4aa367de').then(log).catch(log)

// checkout.createOrderFromCart('0da6ec84-4804-4e7d-a33e-76cb4aa367de').then(log).catch(log)

// checkout.getOrderById('247d15b2-1a95-4d93-939d-ea987ec627c1').then(log).catch(log)
// checkout.createPayment(paymentDraft).then(log).catch(log)
// checkout.addPaymentToOrder('0a8fe3e4-fa15-4991-9c8a-8cbdbc2c80e2','247d15b2-1a95-4d93-939d-ea987ec627c1').then(log).catch(log)

// checkout
//   .updateOrderCustomState(
//     "67c67c4e-a3ab-4d38-ab0b-741cfd4b3d44",
//     "abaf987f-7be6-4f55-9323-cf8921f28075"
//   )
//   .then(log)
//   .catch(log);

const checkoutProcess = async () => {
  let emptyCart = await checkout.createCart(cartDraftData);

  let filledCart = await checkout.addLineItemsToCart(
    ["123", "123",'123'],
    emptyCart.body.id
  );
  filledCart = await checkout.addDiscountCodeToCart(
    "SPLASH",
    emptyCart.body.id
  );
  const payment = await checkout.createPayment(paymentDraft);
  let order = await checkout.createOrderFromCart(filledCart.body.id);
  order = await checkout.addPaymentToOrder(payment.body.id,order.body.id);
  order = await checkout.setOrderState('Confirmed',order.body.id);
  if (order) {
    log(order)
    return {
      status: 201,
      message: "order created",
    };
  }

};

checkoutProcess().then(log).catch(log);
