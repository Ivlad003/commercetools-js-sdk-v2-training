const { simulatePagination } = require("./handson/search");
const { log } = require("./logger");


simulatePagination(4, 1).then(products =>{
    products.body.results.forEach(element => {
        log(element.id)
    });
}).catch(log);