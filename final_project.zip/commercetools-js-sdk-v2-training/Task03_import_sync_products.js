const { createImportSink, importProducts,checkImportOperationStatus } = require("./handson/importService");
const { log } = require("./logger.js");

// createImportSink({
//     key:'ib3-productsImporterAndSync',
//     resourceType:'product-draft'
// }).then(log).catch(log);

// importProducts("ib3-productsImporterAndSync").then(log).catch(log);
// checkImportOperationStatus("ib3-productsImporterAndSync","5d881915-ae65-4f87-9083-2ab8f91eb2ec").then(log).catch(log);
// checkImportOperationStatus("ib3-productsImporterAndSync","ef6032ab-2418-4c44-ad48-7758675da1cb").then(log).catch(log);


https://github.com/commercetools/commercetools-project-sync#run
// docker run \
// -e SOURCE_AUTH_URL=https://auth.europe-west1.gcp.commercetools.com \ 
// -e SOURCE_API_URL=https://api.europe-west1.gcp.commercetools.com \
// -e SOURCE_PROJECT_KEY=happy-garden-dev-jan11 \
// -e SOURCE_CLIENT_ID=ynRYE7WbSf_u9KXCjm_dS7SD \
// -e SOURCE_CLIENT_SECRET=SYFGk4ZB4R6u-Ytmh60eeAbZj-aEZzi1 \
// -e TARGET_PROJECT_KEY=happy-garden-test-jan11 \
// -e TARGET_CLIENT_ID=8u9Waf_J-KRHIG3J9D2bgeNG \
// -e TARGET_CLIENT_SECRET=iN4P21ucP0ZNlaEdXXkGxARYxVhDhXft \
// -e TARGET_AUTH_URL=https://auth.europe-west1.gcp.commercetools.com \
// -e TARGET_API_URL=https://api.europe-west1.gcp.commercetools.com \
// commercetools/commercetools-project-sync:3.10.1 -s all
