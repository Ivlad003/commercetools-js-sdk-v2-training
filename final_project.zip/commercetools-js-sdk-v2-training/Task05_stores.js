const { getCustomersInStore, getMe } = require("./handson/store");
const { log } = require("./logger");

// getCustomersInStore('berlin-store').then(customers => {
//     log(customers.body.count)
// }).catch(log);

getMe().then(log).catch(log);
