const { apiRoot, projectKey } = require("./client.js");

module.exports.getAllProducts = () =>
    apiRoot.withProjectKey({ projectKey })
    .products()
    .get()
    .execute()

// filter query recalculates everything
// filter facet recalculates others only
module.exports.simulateSearch = () =>
    apiRoot.withProjectKey({ projectKey })
        .productProjections()
        .search()
        .get({
            queryArgs: {
                filter: 'categories.id:"5573d694-ad4e-4d09-9747-aa6adb59c119"',
                facet: ['variants.attribute.size', 'variants.attribute.color'],
                "filter.facets": 'variants.attribute.size:120'
            }
        })
        .execute()

module.exports.simulatePagination = (perPage, page) =>
    apiRoot.withProjectKey({ projectKey })
    .productProjections()
    .get({
        queryArgs: {
            limit: perPage,
            offset: perPage * (page - 1)
        }
    })
    .execute()