// @ts-check
const { apiRoot, projectKey } = require("./client.js");

module.exports.createCart = (cartDraftData) =>
  apiRoot
    .withProjectKey({ projectKey })
    .carts()
    .post({
      body: createCartDraft(cartDraftData),
    })
    .execute();

const createCartDraft = (cartDraftData) => {
  const { currency, customerId, countryCode } = cartDraftData;

  return {
    currency,
    customerId,
    shippingAddress: {
      country: countryCode,
    },
  };
};

module.exports.customerSignIn = (customerDetails) =>
  apiRoot.withProjectKey({ projectKey }).login().post({ body: customerDetails }).execute()

module.exports.getCartById = (ID) =>
  apiRoot
    .withProjectKey({ projectKey })
    .carts()
    .withId({ ID })
    .get()
    .execute();

module.exports.addLineItemsToCart = (arrayOfSKUs, cartId) =>
  this.getCartById(cartId).then((cart) => {
    const actions = arrayOfSKUs.map((sku) => {
      return {
        action: "addLineItem",
        sku,
      };
    });

    return apiRoot
      .withProjectKey({ projectKey })
      .carts()
      .withId({ ID: cart.body.id })
      .post({
        body: {
          actions,
          version: cart.body.version
        }
      })
      .execute()
  });

module.exports.addDiscountCodeToCart = (discountCode, cartId) => 
  this.getCartById(cartId).then(cart => {
    return apiRoot
      .withProjectKey({ projectKey })
      .carts()
      .withId({ ID: cart.body.id })
      .post({
        body: {
          version: cart.body.version,
          actions: [{
            action: 'addDiscountCode',
            code: discountCode
          }]
        }
      })
      .execute()
  })

module.exports.createOrderFromCart = (cartId) => {
  return createOrderFromCartDraft(cartId).then(orderFromCartDraft => {
    return apiRoot
      .withProjectKey({ projectKey })
      .orders()
      .post({
        body: orderFromCartDraft
      })
      .execute()
  })
}

const createOrderFromCartDraft = (cartId) => {
  return this.getCartById(cartId).then((cart) => {
    return {
      id: cart.body.id,
      version: cart.body.version,
    };
  });
};

module.exports.getOrderById = (ID) =>
  apiRoot
    .withProjectKey({ projectKey })
    .orders().withId({ ID }).get().execute()

module.exports.updateOrderCustomState = (customStateId, orderId) => {};

module.exports.createPayment = (paymentDraft) => 
  apiRoot
  .withProjectKey({ projectKey })
  .payments()
  .post({
    body: paymentDraft
  })
  .execute()

module.exports.setOrderState = (stateName, orderId) => 
  this.getOrderById(orderId).then(order => {
    return apiRoot
    .withProjectKey({ projectKey })
    .orders()
    .withId({ ID: orderId })
    .post({
      body: {
        version: order.body.version,
        actions: [{
          action: 'changeOrderState',
          orderState: stateName
        }]
      }
    })
    .execute()
  })

module.exports.addPaymentToOrder = (paymentId, orderId) => {
  return this.getOrderById(orderId).then(order => {
    return apiRoot
      .withProjectKey({ projectKey })
      .orders()
      .withId({ ID: orderId })
      .post({
        body: {
          actions: [
            {
              action: 'addPayment',
              payment: {
                id: paymentId,
                typeId: 'payment'
              }
            }
          ],
          version: order.body.version
        }
      })
      .execute()
  })
};
