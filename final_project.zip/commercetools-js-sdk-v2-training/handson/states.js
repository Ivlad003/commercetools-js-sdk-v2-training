const { apiRoot, projectKey } = require("./client.js");

module.exports.createNewState = (stateDraftData) =>
  apiRoot.withProjectKey({ projectKey })
  .states()
  .post({
    body: stateDraftData
  }).execute()

const createStateDraft = (stateDraftData) => {
  const { key, type, name, initial } = stateDraftData;
  return {
    key,
    type,
    name,
    initial,
  };
};

module.exports.getStateByKey = (key) =>{}

module.exports.getStateById = (ID) =>
  apiRoot.withProjectKey({ projectKey })
  .states()
  .withId({ ID })
  .get()
  .execute()

module.exports.addTransition = (stateId, transitionStateId) =>
  this.getStateById(stateId).then(state => {
    return apiRoot.withProjectKey({ projectKey })
      .states()
      .withId({ ID: stateId })
      .post({
        body: {
          actions: [{
            action: 'setTransitions',
            transitions: [{
              typeId: 'state',
              id: transitionStateId
            }]
          }],
          version: state.body.version
        }
      })
      .execute()
  })
