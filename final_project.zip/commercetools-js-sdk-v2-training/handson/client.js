const {
  createAuthMiddlewareForClientCredentialsFlow,
  createAuthMiddlewareForPasswordFlow,
} = require("@commercetools/sdk-middleware-auth");
const { createHttpMiddleware } = require("@commercetools/sdk-middleware-http");
const { createClient } = require("@commercetools/sdk-client");
const {
  createApiBuilderFromCtpClient,
} = require("@commercetools/typescript-sdk");

const {
  createApiBuilderFromCtpClient: createApiBuilderFromCtpClientOnlyForImports,
} = require("@commercetools/importapi-sdk");
require("dotenv").config();

const fetch = require("node-fetch");

const projectKey = process.env.projectKey;

//use .env for credentials process.env.adminClientId 

const getClient = () => {
  const authMiddleware = createAuthMiddlewareForClientCredentialsFlow({
    host: process.env.authUrl,
    projectKey,
    credentials: {
      clientId: process.env.adminClientId,
      clientSecret: process.env.adminClientSecret,
    },
    scopes: [process.env.scopes],
    fetch,
  })
  const httpMiddleware = createHttpMiddleware({
    host: process.env.apiUrl,
    fetch,
  })
  const client = createClient({
    middlewares: [authMiddleware, httpMiddleware],
  })

  return client
};

const getImportClient = () => {
  const authMiddleware = createAuthMiddlewareForClientCredentialsFlow({
    host: process.env.authUrl,
    projectKey,
    credentials: {
      clientId: process.env.adminClientId,
      clientSecret: process.env.adminClientSecret,
    },
    scopes: [process.env.scopes],
    fetch,
  })
  const httpMiddleware = createHttpMiddleware({
    host: process.env.importApiUrl,
    fetch,
  })
  const client = createClient({
    middlewares: [authMiddleware, httpMiddleware],
  })

  return client
};

const getStoreClient = () => {
  const authMiddleware = createAuthMiddlewareForClientCredentialsFlow({
    host: process.env.authUrl,
    projectKey,
    credentials: {
      clientId: process.env.storeClientId,
      clientSecret: process.env.storeClientSecret,
    },
    scopes: [process.env.storeScopes],
    fetch,
  })
  const httpMiddleware = createHttpMiddleware({
    host: process.env.apiUrl,
    fetch,
  })
  const client = createClient({
    middlewares: [authMiddleware, httpMiddleware],
  })

  return client
};

const getMLClient = () => {};

const getMyAPIClient = () => {
  const authMiddleware = createAuthMiddlewareForPasswordFlow({
    host: 'https://auth.europe-west1.gcp.commercetools.com',
    projectKey,
    credentials: {
      clientId: 'Jl5cJ424An5GMhZJUYYUN0UU',
      clientSecret: '7FHkB7osSjY2O2tCX0J6hlF03fTkpyXs',
      user: {
        username: 'exmdmetal2@test.com',
        password: '123'
      }
    },
    scopes: ['view_categories:eu-happy-garden-center-dev-march-10 manage_my_profile:eu-happy-garden-center-dev-march-10 create_anonymous_token:eu-happy-garden-center-dev-march-10 view_published_products:eu-happy-garden-center-dev-march-10 manage_my_shopping_lists:eu-happy-garden-center-dev-march-10 manage_my_orders:eu-happy-garden-center-dev-march-10 manage_my_payments:eu-happy-garden-center-dev-march-10'],
    fetch,
  })
  const httpMiddleware = createHttpMiddleware({
    host: 'https://api.europe-west1.gcp.commercetools.com',
    fetch,
  })
  const client = createClient({
    middlewares: [authMiddleware, httpMiddleware],
  })

  client.execute()

  return client
};

module.exports.apiRoot = createApiBuilderFromCtpClient(getClient());

module.exports.importApiRoot = createApiBuilderFromCtpClientOnlyForImports(
  getImportClient()
);

module.exports.storeApiRoot = createApiBuilderFromCtpClient(getStoreClient());

module.exports.myApiRoot = createApiBuilderFromCtpClient(getMyAPIClient());
module.exports.projectKey = projectKey;