const states = require("./handson/states");
const { log } = require("./logger.js");

const stateDraftData = {
  key: "test-order-shipped",
  type: "OrderState",
  name: {
    "de": "test Order Shipped",
  },
  initial: false,
};

// states.createNewState(stateDraftData).then(log).catch(log)

// states.getStateById("5c008087-6146-4412-9f46-9442089757e3").then(log).catch(log)

states.addTransition("d0e3323e-c425-4619-a579-12492f9f437a", "a6e6280a-b124-4dc7-a4db-3d5bb3c709e2").then(log).catch(log)
