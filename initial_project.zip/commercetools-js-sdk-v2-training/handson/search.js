const { apiRoot, projectKey } = require("./client.js");

module.exports.getAllProducts = () =>{}

// filter query recalculates everything
// filter facet recalculates others only
module.exports.simulateSearch = () =>{}

module.exports.simulatePagination = (perPage, page) =>{}
