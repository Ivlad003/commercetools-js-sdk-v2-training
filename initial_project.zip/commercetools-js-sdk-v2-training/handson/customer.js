const { apiRoot, projectKey } = require("./client.js");

module.exports.getCustomerById = (ID) =>{}

module.exports.getCustomerByKey = (key) =>{}

const createCustomerDraft = (customerData) => {}

module.exports.createCustomer = (customerData) =>{}

const createCustomerDraftKey = (customerData) => {};

module.exports.createCustomerKeyVerfiedEmail = (customerData) =>{}

module.exports.assignCustomerToCustomerGroup = (
  customerKey,
  customerGroupKey
) => {}
