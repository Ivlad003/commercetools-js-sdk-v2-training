const { storeApiRoot, myApiRoot, projectKey } = require("./client.js");

//TODO store and me endpoint

module.exports.getCustomersInStore = (storeKey) =>{}

//use me endpoint with another client
module.exports.getMe = () =>{}

 
