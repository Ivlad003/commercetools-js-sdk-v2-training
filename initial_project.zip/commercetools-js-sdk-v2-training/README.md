# commercetools-js-sdk-v2-training
commercetools-js-sdk-v2-training

https://ok.commercetools.com/training-offering-calendar

NEW JAVASCRIPT COURSE USING THE NEW COMMERCETOOLS JS SDK 
https://github.com/commercetools/commercetools-sdk-typescript#sdk

Usage

Add API Client Credentials in .env.sample then remove the ".sample" file name should be only ".env"
then follow your trainer instructions to solve the exercises.

use the command yarn to install dependencies

then you should be able to run any file using yarn [fileNumber] 
example
yarn 1
yarn 4c 
yarn 6b


for questions email training@commercetools.com